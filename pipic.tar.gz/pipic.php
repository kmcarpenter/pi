<?php
        /**
	 *  PiPic: Create an image of pi by mapping colors to a picture.
         *
         *  Copyright (C) 2008  Michael Carpenter (mcarpent@zenwerx.com)
         *
         *  This program is free software; you can redistribute it and/or modify
         *  it under the terms of the GNU General Public License as published by
         *  the Free Software Foundation; either version 2 of the License, or
         *  (at your option) any later version.
         *
         *  This program is distributed in the hope that it will be useful,
         *  but WITHOUT ANY WARRANTY; without even the implied warranty of
         *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
         *  GNU General Public License for more details.
         *
         *  You should have received a copy of the GNU General Public License
         *  along with this program in the file COPYING; if not, write to the
         *  Free Software Foundation, Inc., 51 Franklin St, Fifth Floor,
         *  Boston, MA 02110-1301 USA
         */

	/******************************************************************************
	 * CHANGELOG                                                                  *
 	 ******************************************************************************
	 *
	 *
	 * 2008-04-04: Modify while loop to check for is_numeric rather than CR & LF
	 *             Also defined some constants rather than hard coded values
	 *			- Mike
	 * 2008-04-04: Release under GPL
	 *			- Mike
	 * 2008-04-03: Cleanup and Prettification
	 *			- Mike
	 * 2008-04-02: Initial hack together
	 *			- Mike
	 *
	 *
	 */

	// Define some defaults
	define ('MAX_SIZE', 	4194304	);
	define ('MAX_SELECT',      2048 );
	define ('DEFAULT_X',	    300	);
	define ('DEFAULT_Y', 	    300	);
	define ('ERR_TOO_BIG', 	     -1	);
	define ('ERR_NO_PI', 	     -2	);
	define ('ERR_BAD_PARAM',     -3 );
	define ('SUCCESS',	      0	);

	// Build Pi
	function buildPi($dig_x = DEFAULT_X, $dig_y = DEFAULT_Y, $greyscale = false) {

		// Don't go over our maximum size
		$numdigits = $dig_x * $dig_y;
		if ($numdigits > MAX_SIZE) {
			return ERR_TOO_BIG;
		}
		// Use sane values
		if (  $dig_x > MAX_SELECT || $dig_x < 0 || $dig_y > MAX_SELECT || $dig_y < 0 ) {
			return ERR_BAD_PARAM;
		}

		$fname = sprintf("cache/pi%04dx%04d.png", $dig_x, $dig_y);
		$bw_fname = sprintf("cache/bw_pi%04dx%04d.png", $dig_x, $dig_y);
		// Try to used a cached file
		if (!file_exists($fname)) {			
			// Create image and colors 
			$gd = imagecreatetruecolor($dig_x, $dig_y);
			$gdbw = imagecreatetruecolor($dig_x, $dig_y);

			$cols = array( 
                            	imagecolorallocate($gd, 0xFF, 0xFF, 0xFF),
                                imagecolorallocate($gd, 0x00, 0xFF, 0xFF),
                                imagecolorallocate($gd, 0x00, 0x00, 0xFF),
                                imagecolorallocate($gd, 0xFF, 0x00, 0xFF),
                                imagecolorallocate($gd, 0x00, 0xFF, 0x00),
                                imagecolorallocate($gd, 0xFF, 0xA5, 0x00),
                                imagecolorallocate($gd, 0xFF, 0x00, 0x00),
                                imagecolorallocate($gd, 0xFF, 0xFF, 0x00),
                                imagecolorallocate($gd, 0x80, 0x80, 0x80),
                         	imagecolorallocate($gd, 0x00, 0x00, 0x00)
			);

			// Make sure we can get the contents of the pi file
			$pi = file_get_contents("pifile");
			if (!$pi) {
				return ERR_NO_PI;
			}

			// Build and image pixel by pixel
			$c = 0;
			for ($y = 0; $y < $dig_y; $y++) {
				for ($x=0; $x < $dig_x; $x++) {
					while (!is_numeric($pi[$c])) {
						$c++;
					}
					imagesetpixel($gd, $x, $y, $cols[$pi[$c]]);
					$c++;
				}
			}
			imagepng($gd, $fname);
			convertToGrayscale($gd, $dig_x, $dig_y, $bw_fname);
		} 

		return SUCCESS;
	}

	function convertToGrayscale($colImage, $x, $y, $fname) {
		$bwImage = imageCreate($x,$y);
		for ($c = 0; $c < 256; $c++) {     
    			imagecolorallocate($bwImage, $c,$c,$c);
		}
		imagecopymerge($bwImage, $colImage, 0,0,0,0, $x, $y, 100);
		imagepng($bwImage, $fname);
	}

	// Defaults
	$x = DEFAULT_X;
	if (isset($_GET['x']) && is_numeric($_GET['x'])) {
		$x = (int) $_GET['x'];
	}
	$y = DEFAULT_Y;
	if (isset($_GET['y']) && is_numeric($_GET['y'])) {
		$y = (int) $_GET['y'];
	}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Visualize Pi!</title>
		<script type='text/javascript'>
			function calculatePi() {
				x = document.getElementById('x');
				x = parseInt(x.options[x.selectedIndex].value);
				y = document.getElementById('y');
				y = parseInt(y.options[y.selectedIndex].value);
				document.getElementById('digCount').innerHTML = x*y;
			}

			function flipGrayscale() {
				img = document.getElementById('img');
				x = document.getElementById('x');
				x = x.options[x.selectedIndex].text;
                                y = document.getElementById('y');
				y = y.options[y.selectedIndex].text;
				img.src='/pi/cache/bw_pi' + x + 'x' + y + '.png';
				img.onclick = function() { flipColor(); };
			}

			function flipColor() {
				img = document.getElementById('img');
				x = document.getElementById('x');
				x = x.options[x.selectedIndex].text;
                                y = document.getElementById('y');
				y = y.options[y.selectedIndex].text;
				img.src='/pi/cache/pi' + x + 'x' + y + '.png';
				img.onclick = function() { flipGrayscale() };
			}
		</script>
		<style type='text/css'>
			img { border: 1px solid black; }
			a.valid { font-size: 0.6em; }
		</style>
	</head>
	<body onload='calculatePi()'>
	<h1>Visualize Pi!</h1>
	<p>
		For a list of pre-generated pictures check out the <a href='/pi/cache/'>cache</a>. Or have fun 
		looking at <a href='/pi/'>4 million digits</a> of pi. If you would like to create your own page
		using a script like this one, you can <a href='/pipic.tar.gz'>download the source</a> (Licensed
		under the GNU GPL). 
	</p>
	<p>
		Each digit of pi (loaded from the digit page above) is mapped to a color and then stored to 
		the picture shown below!
	</p>
	<p>
		<a class='valid' href="http://validator.w3.org/check?uri=referer">XMTL 1.0 Strict</a>
	</p>
	<div style='float: left'>
		<h1>Color:</h1>
		<ul>
			<li>0 <img src='0.png' alt='0' title='0' /></li>
			<li>1 <img src='1.png' alt='1' title='1' /></li>
			<li>2 <img src='2.png' alt='2' title='2' /></li>
			<li>3 <img src='3.png' alt='3' title='3' /></li>
			<li>4 <img src='4.png' alt='4' title='4' /></li>
			<li>5 <img src='5.png' alt='5' title='5' /></li>
			<li>6 <img src='6.png' alt='6' title='6' /></li>
			<li>7 <img src='7.png' alt='7' title='7' /></li>
			<li>8 <img src='8.png' alt='8' title='8' /></li>
			<li>9 <img src='9.png' alt='9' title='9' /></li>
		</ul>
	</div>
	<div style='float: left; margin-left: 100px'>
	<?php
		// Build picture
		$err = buildPi($x, $y);
		$file = sprintf("pi%04dx%04d.png", $x, $y);
		if ($err == SUCCESS) {
			echo "\t<h1>Pi: $x x $y</h1>\n";
			echo "\t<img src='/pi/cache/$file' id='img' alt='Pi' title='Pi' onclick='flipGrayscale()' />";
		} else {
			switch ($err) {
			case ERR_TOO_BIG:
				echo "\t<h2>Width x Height cannot exceed " . MAX_SIZE . "!</h2>\n";
				break;
			case ERR_NO_PI:
				echo "\t<h2>Can't open PI file!</h2>\n";
				break;
			case ERR_BAD_PARAM:
				echo "\t<h2>Invalid parameter: X & Y must satisfy: 1 <= (x & y) <= " . MAX_SELECT . "!</h2>\n";
				break;
			default:
				echo "\t<h2>Unknown Error</h2>\n";
			}
		}
		// End picture
	?>
	<p>Click image to swap between color and grayscale.</p>
	<form method='get' action='/pi/pipic.php'>
		<table>
		<tr>
			<td>Width (x):</td>
			<td>
				<select id='x' name='x' onchange='calculatePi()'>
				<?php
					// X Select box
					for ($i=1; $i<=MAX_SELECT; $i++) {
						echo "\t\t\t\t<option value='$i'";
						if ($i == $x) { echo " selected='selected' "; }
						echo ">" . sprintf("%04d", $i) . "</option>\n";
					}
					// End X Select
				?>
				</select>
			</td>
		</tr><tr>
			<td>
				Height (y): 
			</td>
			<td>
				<select id='y' name='y' onchange='calculatePi()'>
				<?php
					// Y Select box
					for ($i=1; $i<=MAX_SELECT; $i++) {
						echo "\t\t\t<option value='$i'";
						if ($i == $y) { echo " selected='selected' "; }
						echo ">" . sprintf("%04d", $i) . "</option>\n";
					}
					// End Y  Select
				?>
			
				</select>
			</td>
		</tr><tr>
			<td>
				Digit Count:
			</td>
			<td id='digCount'>
			</td>
		</tr>
	</table>
	<p>
		<input type='submit' value='Load' />
	</p>
	</form>
	</div>
	</body>
</html>
